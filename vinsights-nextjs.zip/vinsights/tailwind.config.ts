import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      fontFamily: {
        sans: ["DM Sans", "sans-serif"],
        display: ["Syne", "sans-serif"],
      },
      colors: {
        dark: "#0d0b14",
        card: "#13101f",
        purple: {
          DEFAULT: "#7c3aed",
          light: "#a855f7",
          dark: "#5b21b6",
        },
        orange: "#f97316",
        pink: "#ec4899",
      },
    },
  },
  plugins: [],
};
export default config;
