import Image from "next/image";

const tools = [
  {
    emoji: "🐍",
    color: "text-yellow-400",
    bg: "bg-yellow-500/20",
    border: "border-yellow-500/30",
    title: "Python & Generative AI",
    desc: "Leveraging open-source frameworks, fine-tuning large language models, and operating embeddings to power advanced AI-driven applications.",
  },
  {
    emoji: "💬",
    color: "text-blue-400",
    bg: "bg-blue-500/20",
    border: "border-blue-500/30",
    title: "Customer Engagement & Chatbots",
    desc: "Using Python tools for prompt engineering and LLM for delivering context-aware, multi-channel conversational experience.",
  },
  {
    emoji: "☁️",
    color: "text-orange-400",
    bg: "bg-orange-500/20",
    border: "border-orange-500/30",
    title: "Cloud Infrastructure",
    desc: "GCP, AWS and Azure hybrid cloud for scalable training, storage, serverless functions and real-time model serving strategy.",
  },
  {
    emoji: "⚙️",
    color: "text-green-400",
    bg: "bg-green-500/20",
    border: "border-green-500/30",
    title: "Development & DevOps",
    desc: "React, Next and FastAPI for rapid app development, plus Git and Docker for source control and deployment.",
  },
];

export default function ToolsTech() {
  return (
    <section className="px-6 py-24 section-purple md:px-12">
      <div className="grid gap-12 items-center mx-auto max-w-7xl md:grid-cols-2">
        <div className="fade-left">
          <p className="mb-3 text-xs tracking-widest uppercase text-white/60">
            Powered By
          </p>
          <h2 className="mb-8 text-4xl font-bold text-white font-display">
            Our Tools &<br />
            Technologies
          </h2>
          <div className="space-y-2">
            {tools.map((tool) => (
              <div key={tool.title} className="tool-item">
                <div
                  className={`flex flex-shrink-0 justify-center items-center w-10 h-10 text-lg ${tool.color} rounded-xl border ${tool.bg} ${tool.border}`}
                >
                  {tool.emoji}
                </div>
                <div>
                  <div className="mb-1 text-sm font-semibold text-white">
                    {tool.title}
                  </div>
                  <div className="text-xs text-white/60">{tool.desc}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
        <div className="fade-right">
          <Image
            src="https://images.unsplash.com/photo-1518770660439-4636190af475?w=600&q=80"
            alt="Tech"
            width={600}
            height={320}
            className="object-cover w-full h-80 rounded-2xl"
          />
        </div>
      </div>
    </section>
  );
}
