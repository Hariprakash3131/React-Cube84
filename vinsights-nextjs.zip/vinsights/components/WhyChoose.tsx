const stats = [
  { target: 50, suffix: "+", label: "Team Members" },
  { target: 100, suffix: "%", label: "Success Rate" },
  { target: 50, suffix: "+", label: "Projects Complete" },
  { target: 1200, suffix: "+", label: "Happy Clients" },
];

export default function WhyChoose() {
  return (
    <section className="px-6 py-24 md:px-12 bg-dark">
      <div className="mx-auto max-w-7xl">
        <div className="grid gap-12 items-center p-10 why-card md:p-14 md:grid-cols-2 fade-up">
          <div>
            <h2 className="mb-5 text-4xl font-bold font-display">
              Why Choose <span className="glow-text">Vinsights?</span>
            </h2>
            <p className="mb-6 leading-relaxed text-white/60">
              With extensive experience in Generative AI and deep expertise in
              aligning technology with real business needs, Vinsights results in
              crafting customised, impactful solutions.
            </p>
            <button className="px-7 py-3 text-sm font-medium btn-primary">
              Contact Us →
            </button>
          </div>
          <div className="grid grid-cols-2 gap-6">
            {stats.map((s) => (
              <div key={s.label} className="text-center">
                <div
                  className="mb-1 text-5xl font-bold stat-num glow-text"
                  data-target={s.target}
                  data-suffix={s.suffix}
                >
                  0{s.suffix}
                </div>
                <div className="mt-1 text-xs text-white/50">{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
