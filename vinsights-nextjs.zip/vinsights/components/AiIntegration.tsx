export default function AiIntegration() {
  return (
    <section className="px-6 py-24 md:px-12 bg-dark">
      <div className="mx-auto max-w-7xl">
        <div className="mb-16 text-center fade-up">
          <h2 className="mb-4 text-4xl font-bold font-display md:text-5xl">
            AI Integration & <span className="glow-text">Custom Software</span>
            <br />
            <span className="glow-text-pink">Solutions</span>
          </h2>
          <p className="mx-auto max-w-2xl text-white/50">
            At Vinsight, we recognise every business has unique AI integration
            needs. Our custom services seamlessly embed AI into your existing
            platforms.
          </p>
        </div>
        <div className="grid gap-6 md:grid-cols-3">
          <div className="p-7 service-card fade-up">
            <div className="mb-5 icon-box">
              <svg
                width="20"
                height="20"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
                className="text-purple-light"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"
                />
              </svg>
            </div>
            <h3 className="mb-3 text-lg font-bold text-white font-display">
              Natural Language Processing
            </h3>
            <p className="mb-4 text-sm leading-relaxed text-white/60">
              Enhance customer interactions through sophisticated NLP agents —
              seamlessly integrated with your existing CRM, WhatsApp, and
              support systems.
            </p>
            <a
              href="#"
              className="flex gap-1 items-center text-sm text-purple-light hover:underline"
            >
              Learn more →
            </a>
          </div>
          <div className="p-7 service-card fade-up">
            <div className="mb-5 icon-box">
              <svg
                width="20"
                height="20"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
                className="text-purple-light"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"
                />
              </svg>
            </div>
            <h3 className="mb-3 text-lg font-bold text-white font-display">
              AI Implementation Analysis
            </h3>
            <p className="mb-4 text-sm leading-relaxed text-white/60">
              Our dedicated development team evaluates your processes and
              systems, pinpointing key areas where generative AI can
              significantly enhance efficiency.
            </p>
            <a
              href="#"
              className="flex gap-1 items-center text-sm text-purple-light hover:underline"
            >
              Learn more →
            </a>
          </div>
          <div className="p-7 service-card fade-up">
            <div className="mb-5 icon-box">
              <svg
                width="20"
                height="20"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
                className="text-purple-light"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
                />
              </svg>
            </div>
            <h3 className="mb-3 text-lg font-bold text-white font-display">
              Scheduled Strategic Consultation
            </h3>
            <p className="mb-4 text-sm leading-relaxed text-white/60">
              Following the analysis, we arrange a strategic consultation to
              discuss findings, recommend practical AI solutions and define
              actionable next steps.
            </p>
            <a
              href="#"
              className="flex gap-1 items-center text-sm text-purple-light hover:underline"
            >
              Learn more →
            </a>
          </div>
        </div>
        <div className="mt-10 text-center fade-up">
          <button className="px-8 py-3 text-sm font-medium btn-primary">
            View All Services →
          </button>
        </div>
      </div>
    </section>
  );
}
