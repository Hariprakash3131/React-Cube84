const steps = [
  {
    num: "1",
    title: "AI Readiness Assessment",
    desc: "We assess your current systems and identify key opportunities where AI can streamline processes and drive sustainable business growth.",
  },
  {
    num: "2",
    title: "Custom AI Roadmap",
    desc: "Based on your specific needs, we develop a clear, step-by-step plan that details how to effectively integrate AI tools and processes into your business.",
  },
  {
    num: "3",
    title: "Support & Optimisation",
    desc: "Once deployed, we provide continuous, personalised calibration to ensure your business and AI systems are always running at peak performance.",
  },
];

export default function ConsultingProcess() {
  return (
    <section className="px-6 py-24 md:px-12 bg-dark">
      <div className="mx-auto max-w-7xl text-center">
        <h2 className="mb-4 text-4xl font-bold font-display">
          Our <span className="glow-text">Consulting Process</span>
        </h2>
        <p className="mb-16 text-white/50">
          Unlock your business&apos;s potential with our comprehensive AI
          solutions
        </p>
        <div className="grid relative gap-6 md:grid-cols-3">
          {steps.map((step, i) => (
            <div
              key={i}
              className="p-8 process-step fade-up"
              style={{ animationDelay: `${i * 0.15}s` }}
            >
              <div className="flex justify-center items-center mx-auto mb-5 w-12 h-12 text-lg font-bold rounded-full border bg-purple/20 border-purple/40 text-purple-light font-display">
                {step.num}
              </div>
              <h3 className="mb-3 text-lg font-bold text-white font-display">
                {step.title}
              </h3>
              <p className="text-sm leading-relaxed text-white/50">
                {step.desc}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
