const testimonials = [
  {
    stars: 5,
    quote:
      "Vinsights' experts seamlessly integrated AI into our CRM workflow. Within a month, our lead qualification rate improved by 40%, and our sales reps saved an average of 10 hours per week.",
    name: "Vikram Singh",
    role: "Head of Growth, FinEdge",
  },
  {
    stars: 5,
    quote:
      "Thanks to Vinsights' tailored AI consulting, we identified high-impact use cases that boosted our operational efficiency by 35% within three months — and their ongoing support helped us scale fast.",
    name: "Meera Iyer",
    role: "COO, Lumen Health",
  },
  {
    stars: 5,
    quote:
      "Working with Vinsights transformed our support experience. Their tailored AI model handled 80% of routine inquiries without human intervention — our team can now focus on high-value tasks.",
    name: "Priya Menon",
    role: "CX Lead, Nivara Retail",
  },
];

export default function Testimonials() {
  return (
    <section className="px-6 py-24 section-purple md:px-12">
      <div className="mx-auto max-w-7xl text-center">
        <div className="mb-4 text-5xl text-white/30 font-display">&ldquo;</div>
        <h2 className="mb-2 text-4xl font-bold text-white font-display">
          What people are saying…
        </h2>
        <p className="mb-12 text-white/60">
          Read the testimonials of our happy customers
        </p>
        <div className="grid gap-6 text-left md:grid-cols-3">
          {testimonials.map((t, i) => (
            <div
              key={i}
              className="p-7 testi-card fade-up"
              style={{ animationDelay: `${i * 0.15}s` }}
            >
              <div className="flex gap-1 mb-4">{"⭐".repeat(t.stars)}</div>
              <p className="mb-6 text-sm leading-relaxed text-white/80">
                &ldquo;{t.quote}&rdquo;
              </p>
              <div>
                <div className="text-sm font-semibold text-white">{t.name}</div>
                <div className="text-xs text-white/40">{t.role}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
