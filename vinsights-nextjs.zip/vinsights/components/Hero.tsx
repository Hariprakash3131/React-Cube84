"use client";

import { useEffect, useRef } from "react";

function useScrollAnimation() {
  useEffect(() => {
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const el = entry.target as HTMLElement;
            el.style.transition = "opacity 0.7s ease, transform 0.7s ease";
            el.style.opacity = "1";
            el.style.transform = "none";
            io.unobserve(el);
          }
        });
      },
      { threshold: 0.15 }
    );
    document.querySelectorAll(".fade-up, .fade-left, .fade-right").forEach((el) =>
      io.observe(el)
    );
    return () => io.disconnect();
  }, []);
}

function useCounterAnimation() {
  useEffect(() => {
    function animateCounter(el: HTMLElement) {
      const target = parseInt(el.dataset.target || "0");
      const suffix = el.dataset.suffix || "%";
      const duration = 1800;
      const start = performance.now();
      function update(now: number) {
        const t = Math.min((now - start) / duration, 1);
        const eased = 1 - Math.pow(1 - t, 3);
        el.textContent = Math.round(eased * target) + suffix;
        if (t < 1) requestAnimationFrame(update);
      }
      requestAnimationFrame(update);
    }

    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const el = entry.target as HTMLElement;
            if (el.dataset.target) animateCounter(el);
            io.unobserve(el);
          }
        });
      },
      { threshold: 0.15 }
    );
    document.querySelectorAll("[data-target]").forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, []);
}

export default function Hero() {
  useScrollAnimation();
  useCounterAnimation();

  return (
    <section className="flex overflow-hidden relative flex-col justify-center px-6 pt-24 pb-16 min-h-screen hero-bg md:px-12">
      {/* Floating orbs */}
      <div
        className="top-20 left-1/4 w-96 h-96 orb bg-purple/30"
        style={{ animation: "float 8s ease-in-out infinite" }}
      />
      <div
        className="bottom-20 right-1/4 w-64 h-64 orb bg-orange/20"
        style={{ animation: "float 10s ease-in-out infinite 2s" }}
      />

      <div className="grid gap-12 items-center mx-auto w-full max-w-7xl md:grid-cols-2">
        {/* LEFT */}
        <div className="fade-left">
          <div className="mb-6 badge text-white/80">
            Next-Gen AI Solutions for Enterprise
          </div>
          <h1 className="mb-6 text-5xl font-bold leading-tight font-display md:text-6xl">
            Revolutionize Your
            <br />
            Business With
            <br />
            <span className="glow-text">Intelligent AI</span>
          </h1>
          <p className="mb-8 max-w-md text-lg leading-relaxed text-white/60">
            At Vinsights Solutions, we specialize in building next-generation AI
            systems that transform how businesses operate, engage, and grow. Our
            mission is to deliver intelligent, scalable solutions.
          </p>
          <div className="flex gap-4 items-center mb-6">
            <button className="px-7 py-3 h-12 text-lg font-medium rounded-full btn-primary">
              <span>Contact Us</span>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="18"
                height="18"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M5 12h14" />
                <path d="m12 5 7 7-7 7" />
              </svg>
            </button>
            <button className="inline-flex items-center justify-center gap-2 whitespace-nowrap font-medium transition-colors border shadow-sm py-2 rounded-full h-12 px-7 text-lg bg-white/5 border-white/20 hover:bg-white/10 text-white">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="18"
                height="18"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M8 2v4" />
                <path d="M16 2v4" />
                <rect width="18" height="18" x="3" y="4" rx="2" />
                <path d="M3 10h18" />
              </svg>
              <span>Get a Demo</span>
            </button>
          </div>
          <div className="flex gap-6 items-center text-sm text-white/50">
            <span className="flex gap-2 items-center">
              <span className="w-4 h-4 flex items-center justify-center text-[8px] text-green-400 rounded-full ring-1 ring-green-400">
                ✓
              </span>{" "}
              Free 14-day trial
            </span>
            <span className="flex gap-2 items-center">
              <span className="w-4 h-4 inline-flex items-center justify-center text-[8px] leading-none text-green-400 rounded-full ring-1 ring-green-400">
                ✓
              </span>{" "}
              No credit card required
            </span>
          </div>
        </div>

        {/* RIGHT: CHAT WIDGET */}
        <div className="flex justify-center fade-right">
          <div className="relative p-5 w-full max-w-sm chat-box">
            <div className="flex absolute -top-3 right-4 gap-2 items-center px-3 py-1 text-xs rounded-full border bg-dark border-purple/30 text-purple-light">
              <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />{" "}
              Replies in 0.4s
            </div>
            {/* Header */}
            <div className="flex gap-3 items-center pb-4 mb-4 border-b border-white/10">
              <div className="flex gap-1.5">
                <div className="w-3 h-3 bg-red-400 rounded-full" />
                <div className="w-3 h-3 bg-yellow-400 rounded-full" />
                <div className="w-3 h-3 bg-green-400 rounded-full" />
              </div>
              <div className="flex gap-2 items-center ml-2">
                <div className="flex justify-center items-center w-7 h-7 text-xs font-bold bg-gradient-to-br rounded-full from-purple to-orange">
                  A
                </div>
                <div>
                  <div className="text-xs font-semibold">AISA-X</div>
                  <div className="text-xs text-green-400">● Online</div>
                </div>
              </div>
            </div>
            {/* Messages */}
            <div className="space-y-3 text-sm">
              <div className="chat-bubble-user msg1">
                Hi! Can you check my order #38291?
              </div>
              <div className="chat-bubble-ai msg2">
                Hello Priya 👋 Your order #38291 was dispatched today and will
                arrive on Friday. Want me to share the tracking link?
              </div>
              <div className="chat-bubble-user msg3">Yes please.</div>
              <div className="chat-bubble-ai msg4">
                Here you go — tracking link sent to your email. Anything else I
                can help with?
              </div>
            </div>
            {/* Input */}
            <div className="flex gap-2 items-center p-2.5 mt-4 rounded-xl border bg-white/5 border-white/10">
              <input
                className="flex-1 text-xs bg-transparent outline-none text-white/60"
                placeholder="Type a message..."
              />
              <button className="flex justify-center items-center w-8 h-8 text-sm text-white bg-gradient-to-br rounded-lg from-purple to-purple-light">
                →
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* STATS */}
      <div className="mx-auto mt-16 w-full max-w-5xl fade-up">
        <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
          <div className="p-6 text-center stat-card">
            <div
              className="mb-1 text-4xl font-bold stat-num glow-text"
              data-target="45"
              data-suffix="%"
            >
              0%
            </div>
            <div className="mx-auto mb-2 w-6 h-1 bg-gradient-to-r rounded from-purple to-orange" />
            <div className="text-xs text-white/50">
              Visits-to-Lead Improvement
            </div>
          </div>
          <div className="p-6 text-center stat-card">
            <div
              className="mb-1 text-4xl font-bold stat-num glow-text"
              data-target="79"
              data-suffix="%"
            >
              0%
            </div>
            <div className="mx-auto mb-2 w-6 h-1 bg-gradient-to-r rounded from-purple to-orange" />
            <div className="text-xs text-white/50">Cost Saving on Support Staff</div>
          </div>
          <div className="p-6 text-center stat-card">
            <div
              className="mb-1 text-4xl font-bold stat-num glow-text"
              data-target="38"
              data-suffix="%"
            >
              0%
            </div>
            <div className="mx-auto mb-2 w-6 h-1 bg-gradient-to-r rounded from-purple to-orange" />
            <div className="text-xs text-white/50">Efficiency in Lead Capture</div>
          </div>
          <div className="p-6 text-center stat-card">
            <div
              className="mb-1 text-4xl font-bold stat-num glow-text"
              data-target="42"
              data-suffix="%"
            >
              0%
            </div>
            <div className="mx-auto mb-2 w-6 h-1 bg-gradient-to-r rounded from-purple to-orange" />
            <div className="text-xs text-white/50">Improvement in Revenue</div>
          </div>
        </div>
      </div>
    </section>
  );
}
