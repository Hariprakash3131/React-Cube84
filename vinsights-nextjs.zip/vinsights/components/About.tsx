import Image from "next/image";

export default function About() {
  return (
    <section id="about" className="px-6 py-24 md:px-12 bg-dark">
      <div className="grid gap-16 items-center mx-auto max-w-7xl md:grid-cols-2">
        <div className="relative fade-left">
          <Image
            src="https://images.unsplash.com/photo-1552664730-d307ca884978?w=600&q=80"
            alt="Team"
            width={600}
            height={400}
            className="object-cover w-full h-80 rounded-2xl md:h-96"
          />
          <div className="absolute right-4 bottom-4 px-4 py-3 rounded-xl border backdrop-blur bg-dark/90 border-purple/30">
            <div className="text-2xl font-bold font-display glow-text">+86%</div>
            <div className="text-xs text-white/50">Customer Engagement</div>
          </div>
        </div>
        <div className="fade-right">
          <p className="mb-3 text-xs tracking-widest uppercase text-white/40">
            About Us
          </p>
          <h2 className="mb-5 text-4xl font-bold font-display">
            Empowering Enterprises with{" "}
            <span className="glow-text">AI Automation</span>
          </h2>
          <p className="mb-6 leading-relaxed text-white/60">
            Vinsights Solutions is a forward-thinking technology company focused
            on building real-world AI products that solve customer engagement,
            operations and automation challenges. With AISA-X, Vinsights is
            redefining how businesses interact with customers — intelligently,
            seamlessly and at scale.
          </p>
          <a
            href="#"
            className="flex gap-2 items-center text-sm text-purple-light hover:underline"
          >
            Read our full story →
          </a>
        </div>
      </div>
    </section>
  );
}
