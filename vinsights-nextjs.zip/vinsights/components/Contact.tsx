export default function Contact() {
  return (
    <section id="contact" className="px-6 py-24 md:px-12 bg-dark">
      <div className="grid gap-16 items-center mx-auto max-w-7xl md:grid-cols-2">
        <div className="fade-left">
          <p className="mb-3 text-xs tracking-widest uppercase text-white/40">
            Get In Touch
          </p>
          <h2 className="mb-4 text-4xl font-bold font-display">
            Let&apos;s build your <span className="glow-text">AI advantage</span>
          </h2>
          <p className="mb-10 leading-relaxed text-white/50">
            Share a few details about your goals and our team will get back
            within 24 hours with a tailored plan.
          </p>
          <div className="space-y-5 text-sm text-white/60">
            <div className="flex gap-3 items-center">
              <div className="w-9 h-9 icon-box">
                <svg
                  width="16"
                  height="16"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                  className="text-purple-light"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
                  />
                </svg>
              </div>{" "}
              hello@vinsights.ai
            </div>
            <div className="flex gap-3 items-center">
              <div className="w-9 h-9 icon-box">
                <svg
                  width="16"
                  height="16"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                  className="text-purple-light"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"
                  />
                </svg>
              </div>{" "}
              +91 8086 1196
            </div>
            <div className="flex gap-3 items-center">
              <div className="w-9 h-9 icon-box">
                <svg
                  width="16"
                  height="16"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                  className="text-purple-light"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"
                  />
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"
                  />
                </svg>
              </div>{" "}
              Powered by Logic, Bangalore
            </div>
          </div>
        </div>

        <div className="p-8 rounded-2xl border bg-card border-white/[0.08] fade-right">
          <div className="grid grid-cols-2 gap-4 mb-4">
            <div>
              <label className="block mb-1.5 text-xs text-white/50">
                Your name*
              </label>
              <input className="form-input" placeholder="John Doe" />
            </div>
            <div>
              <label className="block mb-1.5 text-xs text-white/50">
                Business name*
              </label>
              <input className="form-input" placeholder="Acme Inc." />
            </div>
          </div>
          <div className="mb-4">
            <label className="block mb-1.5 text-xs text-white/50">
              Company
            </label>
            <input className="form-input" placeholder="Acme Inc." />
          </div>
          <div className="mb-4">
            <label className="block mb-1.5 text-xs text-white/50">
              Phone no.
            </label>
            <input className="form-input" placeholder="+91 98765 00000" />
          </div>
          <div className="mb-6">
            <label className="block mb-1.5 text-xs text-white/50">
              How can we help?
            </label>
            <textarea
              className="h-24 resize-none form-input"
              placeholder="Tell us about your project..."
            />
          </div>
          <button className="justify-center py-3.5 w-full text-sm font-medium btn-primary">
            Send Message →
          </button>
          <p className="mt-3 text-xs text-center text-white/30">
            We typically respond within 24 hours
          </p>
        </div>
      </div>
    </section>
  );
}
