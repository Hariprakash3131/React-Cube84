"use client";

import { useState } from "react";

const faqs = [
  {
    q: "How long does a typical AI implementation take?",
    a: "Most implementations take between 4–12 weeks depending on complexity. A simple chatbot or workflow automation can be live in under a month, while enterprise-grade multi-system integrations typically take 8–12 weeks with iterative testing.",
  },
  {
    q: "Do you train models on our private data?",
    a: "Yes. We offer fully private fine-tuning pipelines where your data never leaves your environment. All data handling follows GDPR and SOC 2 practices, with optional on-premise deployment for regulated industries.",
  },
  {
    q: "Which channels can your AI agents operate on?",
    a: "Our agents work across web chat, WhatsApp, SMS, email, voice (IVR), and mobile apps. We also integrate natively with Zendesk, Salesforce, HubSpot, and any REST-based CRM or helpdesk.",
  },
  {
    q: "Can you integrate with our existing CRM and tools?",
    a: "Absolutely. We have pre-built connectors for the most popular platforms and can build custom integrations for any system with an API. Our team handles all configuration and testing end-to-end.",
  },
  {
    q: "What kind of support do you provide post-launch?",
    a: "All plans include post-launch support. Growth and Enterprise plans come with dedicated success managers, proactive monitoring, and regular model retraining to ensure your AI continues to improve over time.",
  },
  {
    q: "How do you measure ROI?",
    a: "We baseline key metrics before deployment — ticket volume, handle time, lead conversion, cost-per-interaction — then track them monthly. Most clients see measurable ROI within 60 days of going live.",
  },
];

export default function FAQ() {
  const [open, setOpen] = useState<number | null>(null);

  return (
    <section id="faq" className="px-6 py-24 md:px-12 bg-dark">
      <div className="mx-auto max-w-3xl text-center">
        <p className="mb-3 text-xs tracking-widest uppercase text-white/40">
          FAQ
        </p>
        <h2 className="mb-4 text-4xl font-bold font-display">
          Questions, <span className="glow-text">answered</span>
        </h2>
        <p className="mb-14 text-white/50">
          Everything you need to know before you talk to us.
        </p>
        <div className="space-y-0 text-left fade-up">
          {faqs.map((faq, i) => (
            <div key={i} className="faq-item">
              <button
                className="faq-btn"
                onClick={() => setOpen(open === i ? null : i)}
              >
                <span>{faq.q}</span>
                <div className={`faq-icon${open === i ? " open" : ""}`}>+</div>
              </button>
              <div className={`faq-content${open === i ? " open" : ""}`}>
                {faq.a}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
