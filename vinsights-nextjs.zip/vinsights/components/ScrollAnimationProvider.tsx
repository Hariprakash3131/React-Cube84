"use client";

import { useEffect } from "react";

export default function ScrollAnimationProvider({
  children,
}: {
  children: React.ReactNode;
}) {
  useEffect(() => {
    // Scroll fade-in animations
    const fadeObserver = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const el = entry.target as HTMLElement;
            el.style.transition = "opacity 0.7s ease, transform 0.7s ease";
            el.style.opacity = "1";
            el.style.transform = "none";
            fadeObserver.unobserve(el);
          }
        });
      },
      { threshold: 0.15 }
    );

    // Counter animations
    function animateCounter(el: HTMLElement) {
      const target = parseInt(el.dataset.target || "0");
      const suffix = el.dataset.suffix || "%";
      const duration = 1800;
      const start = performance.now();
      function update(now: number) {
        const t = Math.min((now - start) / duration, 1);
        const eased = 1 - Math.pow(1 - t, 3);
        el.textContent = Math.round(eased * target) + suffix;
        if (t < 1) requestAnimationFrame(update);
      }
      requestAnimationFrame(update);
    }

    const counterObserver = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const el = entry.target as HTMLElement;
            if (el.dataset.target) animateCounter(el);
            counterObserver.unobserve(el);
          }
        });
      },
      { threshold: 0.15 }
    );

    document
      .querySelectorAll(".fade-up, .fade-left, .fade-right")
      .forEach((el) => fadeObserver.observe(el));

    document
      .querySelectorAll("[data-target]")
      .forEach((el) => counterObserver.observe(el));

    // Nav scroll transparency
    const nav = document.querySelector("nav") as HTMLElement | null;
    const handleScroll = () => {
      if (nav) nav.style.background = "transparent";
    };
    window.addEventListener("scroll", handleScroll);

    return () => {
      fadeObserver.disconnect();
      counterObserver.disconnect();
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  return <>{children}</>;
}
