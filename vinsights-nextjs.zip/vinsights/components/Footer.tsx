const services = [
  "Conversational AI Development",
  "AI Model Development",
  "AI Consulting Services",
  "AI Integration Services",
  "Deployment & Management",
  "Industry Solutions",
];

const industries = [
  "Technology & Communication",
  "Manufacturing",
  "Healthcare & Wellness",
  "Finance & Banking",
  "Team & Hospitality",
  "Media & Entertainment",
  "Automotive",
];

const newIndustries = [
  "Finance & Banking",
  "E-commerce & Retail",
  "Defence Industry",
  "Energy Industry",
];

export default function Footer() {
  return (
    <footer className="px-6 py-16 md:px-12">
      <div className="mx-auto max-w-7xl">
        <div className="grid gap-10 mb-12 md:grid-cols-4">
          <div>
            <div className="flex gap-2 items-center mb-4 text-lg font-bold font-display">
              <div className="flex justify-center items-center w-8 h-8 text-sm font-bold text-white bg-gradient-to-br rounded-lg from-purple to-purple-light">
                V
              </div>
              VINSIGHTS
            </div>
            <p className="mb-4 text-xs leading-relaxed text-white/40">
              Zone number 1A, Aksaya park, 544 Sprint Tech Road, 4th Stage, 10th
              to 18th, Ramamurthy nagar, Bangalore
            </p>
            <p className="text-xs text-white/40">Phone: +91 8086 11966</p>
            <div className="flex gap-3 mt-4">
              {["f", "in", "X", "▷"].map((icon) => (
                <a
                  key={icon}
                  href="#"
                  className="flex justify-center items-center w-8 h-8 text-xs rounded-lg border transition-all bg-white/5 border-white/10 text-white/40 hover:text-white hover:border-purple/30"
                >
                  {icon}
                </a>
              ))}
            </div>
          </div>

          <div>
            <h4 className="mb-4 text-sm font-semibold text-white">Services</h4>
            <ul className="space-y-2 text-xs text-white/40">
              {services.map((s) => (
                <li key={s}>
                  <a href="#" className="transition-colors hover:text-white">
                    {s}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="mb-4 text-sm font-semibold text-white">
              Industries
            </h4>
            <ul className="space-y-2 text-xs text-white/40">
              {industries.map((i) => (
                <li key={i}>
                  <a href="#" className="transition-colors hover:text-white">
                    {i}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="mb-4 text-sm font-semibold text-white">
              New Industries
            </h4>
            <ul className="space-y-2 text-xs text-white/40">
              {newIndustries.map((i) => (
                <li key={i}>
                  <a href="#" className="transition-colors hover:text-white">
                    {i}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="flex flex-col gap-4 justify-between items-center pt-8 text-xs border-t border-white/5 md:flex-row text-white/30">
          <span>
            © Copyright 2025 Vinsights. Powered by Kloqto Informatics.
          </span>
          <span>Privacy Policy · Terms of Service</span>
        </div>
      </div>
    </footer>
  );
}
