import Image from "next/image";

export default function Consulting() {
  return (
    <section className="px-6 py-24 md:px-12 bg-dark">
      <div className="grid gap-16 items-center mx-auto max-w-7xl md:grid-cols-2">
        <div className="fade-left">
          <p className="mb-3 text-xs tracking-widest uppercase text-white/40">
            Our Services
          </p>
          <h2 className="mb-5 text-4xl font-bold font-display">
            AI Consulting &{" "}
            <span className="glow-text-pink">Strategy Development</span>
          </h2>
          <p className="mb-8 leading-relaxed text-white/60">
            At Vinsights, we don&apos;t just offer AI solutions — we help you
            build a strategy around AI. Our AI consulting services guide you
            through the entire AI adoption process, from identifying areas where
            AI can make an impact to implementing tools that drive results.
          </p>
          <div className="grid grid-cols-2 gap-3 mb-8">
            {[
              "Strategic Roadmap",
              "ROI Modelling",
              "Risk Assessment",
              "Team Enablement",
            ].map((item) => (
              <div
                key={item}
                className="flex gap-2 items-center px-4 py-3 text-sm rounded-xl border bg-white/[0.04] border-white/[0.08] text-white/70"
              >
                <span className="check-purple">✓</span> {item}
              </div>
            ))}
          </div>
          <a
            href="#"
            className="flex gap-2 items-center text-sm text-purple-light hover:underline"
          >
            Know why we are best →
          </a>
        </div>
        <div className="fade-right">
          <Image
            src="https://images.unsplash.com/photo-1600880292203-757bb62b4baf?w=600&q=80"
            alt="Consulting"
            width={600}
            height={400}
            className="object-cover w-full h-80 rounded-2xl md:h-96"
          />
        </div>
      </div>
    </section>
  );
}
