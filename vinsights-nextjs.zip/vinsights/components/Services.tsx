export default function Services() {
  return (
    <section id="services" className="px-6 py-24 section-purple md:px-12">
      <div className="mx-auto max-w-7xl">
        <p className="mb-3 text-xs tracking-widest uppercase text-white/60">
          Take Your Business to the Next Level
        </p>
        <div className="grid gap-6 items-start md:grid-cols-3">
          <div className="fade-left">
            <h2 className="mb-4 text-4xl font-bold text-white font-display">
              Our Services
            </h2>
            <p className="leading-relaxed text-white/70">
              We help organisations unlock AI value across the entire stack —
              from custom model development to continuous optimisation.
            </p>
          </div>
          <div className="p-7 service-card fade-up">
            <div className="mb-5 icon-box">
              <svg
                width="20"
                height="20"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
                className="text-purple-light"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"
                />
              </svg>
            </div>
            <h3 className="mb-3 text-xl text-white font-display font-bold">
              Tailored AI Model Development
            </h3>
            <p className="text-sm leading-relaxed text-white/60">
              Vinsights creates tailored AI models specifically designed around
              your unique business needs, offering precision, scalability, and
              usability.
            </p>
          </div>
          <div className="p-7 service-card fade-up">
            <div className="mb-5 icon-box">
              <svg
                width="20"
                height="20"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
                className="text-purple-light"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"
                />
              </svg>
            </div>
            <h3 className="mb-3 text-xl text-white font-display font-bold">
              Tailored AI Optimization & Continuous Improvement
            </h3>
            <p className="text-sm leading-relaxed text-white/60">
              Our tailored AI optimization approach involves continuous
              refinement and scaling of your AI systems, ensuring ongoing
              accuracy & reliability.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
