export default function Marquee() {
  const brands = [
    "Aurora AI",
    "BluePeak",
    "Voltrix",
    "NorthBay",
    "Helix Labs",
    "Quaroltrix",
    "Borthi Bay",
  ];

  return (
    <div className="overflow-hidden py-8 border-y border-white/5">
      <p className="mb-5 text-xs tracking-widest text-center uppercase text-white/40">
        Trusted by Forward-Thinking Teams
      </p>
      <div className="flex">
        <div className="marquee-track">
          {[...brands, ...brands].map((brand, i) => (
            <span
              key={i}
              className="text-xl font-semibold text-white/25 font-display"
            >
              {brand}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}
