const verticals = [
  { icon: "🔗", title: "Technology & Communication", sub: "AI copilots, dev tools, smart pipelines" },
  { icon: "🏭", title: "Manufacturing", sub: "Predictive maintenance & QC" },
  { icon: "🏥", title: "Healthcare & Wellness", sub: "Patient triage & medical AI" },
  { icon: "🚗", title: "Automotive", sub: "AI copilots & telematics" },
  { icon: "🏦", title: "Finance & Banking", sub: "Fraud AI & AI-advisories" },
  { icon: "🛒", title: "E-commerce & Retail", sub: "Conversational shopping" },
  { icon: "✈️", title: "Travel & Hospitality", sub: "Itinerary & booking agents" },
  { icon: "🎬", title: "Media & Entertainment", sub: "Content intelligence & search" },
];

export default function Verticals() {
  return (
    <section className="px-6 py-24 md:px-12 bg-dark">
      <div className="mx-auto max-w-7xl text-center">
        <p className="mb-3 text-xs tracking-widest uppercase text-white/40">
          Industries We Serve
        </p>
        <h2 className="mb-4 text-4xl font-bold font-display">
          Built for every <span className="glow-text">vertical</span>
        </h2>
        <p className="mb-12 text-white/50">
          From regulated finance to fast-moving retail: our AI adapts to your
          domain and scales with your stack.
        </p>
        <div className="grid grid-cols-2 gap-4 md:grid-cols-4 fade-up">
          {verticals.map((v) => (
            <div key={v.title} className="text-left vertical-card">
              <div className="mb-3 text-2xl">{v.icon}</div>
              <div className="mb-1 text-sm font-semibold">{v.title}</div>
              <div className="text-xs text-white/40">{v.sub}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
