const starterFeatures = [
  "1 custom AI workflow",
  "1× 1hr chatbot integration",
  "Small support",
  "14-day optimization",
];

const growthFeatures = [
  "Up to 5 AI workflows",
  "Multi-channel chat & voice",
  "CRM & ticketing integrations",
  "Priority support, 99% SLA",
  "Quarterly model training",
];

const enterpriseFeatures = [
  "Unlimited workflows",
  "On-prem / private cloud",
  "Dedicated AI engineer",
  "Custom model training",
  "24/7 white glove support",
];

export default function Pricing() {
  return (
    <section id="pricing" className="px-6 py-24 md:px-12 bg-dark">
      <div className="mx-auto max-w-5xl text-center">
        <p className="mb-3 text-xs tracking-widest uppercase text-white/40">
          Pricing
        </p>
        <h2 className="mb-4 text-4xl font-bold font-display">
          Plans that <span className="glow-text">scale with you</span>
        </h2>
        <p className="mb-16 text-white/50">
          Transparent pricing — pick a plan, change anytime.
        </p>
        <div className="grid gap-6 items-center md:grid-cols-3">
          {/* Starter */}
          <div className="p-8 text-left price-card regular fade-up">
            <div className="mb-2 text-sm text-white/60">Starter</div>
            <div className="mb-1 text-4xl font-bold text-white font-display">
              $1,499<span className="text-lg text-white/40">/mo</span>
            </div>
            <p className="mb-6 text-xs text-white/50">
              For teams piloting AI in a single workflow.
            </p>
            <ul className="mb-8 space-y-3 text-sm text-white/70">
              {starterFeatures.map((f) => (
                <li key={f} className="flex gap-2">
                  <span className="check">✓</span> {f}
                </li>
              ))}
            </ul>
            <button className="justify-center py-3 w-full text-sm btn-outline">
              Get a pilot →
            </button>
          </div>

          {/* Growth */}
          <div className="relative p-8 text-left price-card popular fade-up">
            <div className="absolute -top-4 left-1/2 -translate-x-1/2">
              <span className="text-white popular-badge">MOST POPULAR</span>
            </div>
            <div className="mb-2 text-sm text-white/80">Growth</div>
            <div className="mb-1 text-4xl font-bold text-white font-display">
              $4,999<span className="text-lg text-white/60">/mo</span>
            </div>
            <p className="mb-6 text-xs text-white/70">
              For scaling teams that need multi-channel AI.
            </p>
            <ul className="mb-8 space-y-3 text-sm text-white/90">
              {growthFeatures.map((f) => (
                <li key={f} className="flex gap-2">
                  <span className="check">✓</span> {f}
                </li>
              ))}
            </ul>
            <button className="justify-center py-3 w-full text-sm btn-primary">
              Choose Growth →
            </button>
          </div>

          {/* Enterprise */}
          <div className="p-8 text-left price-card regular fade-up">
            <div className="mb-2 text-sm text-white/60">Enterprise</div>
            <div className="mb-1 text-4xl font-bold font-display glow-text">
              Custom
            </div>
            <p className="mb-6 text-xs text-white/50">
              For organisations that need dedicated AI infrastructure.
            </p>
            <ul className="mb-8 space-y-3 text-sm text-white/70">
              {enterpriseFeatures.map((f) => (
                <li key={f} className="flex gap-2">
                  <span className="check">✓</span> {f}
                </li>
              ))}
            </ul>
            <button className="justify-center py-3 w-full text-sm btn-outline">
              Talk to sales →
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
