import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Vinsights – Intelligent AI Solutions for Business",
  description:
    "Vinsights Solutions specializes in building next-generation AI systems that transform how businesses operate, engage, and grow.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link
          href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:ital,wght@0,300;0,400;0,500;1,300&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>{children}</body>
    </html>
  );
}
