import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import Marquee from "@/components/Marquee";
import Services from "@/components/Services";
import AiIntegration from "@/components/AiIntegration";
import About from "@/components/About";
import Consulting from "@/components/Consulting";
import Testimonials from "@/components/Testimonials";
import ConsultingProcess from "@/components/ConsultingProcess";
import ToolsTech from "@/components/ToolsTech";
import Verticals from "@/components/Verticals";
import Pricing from "@/components/Pricing";
import FAQ from "@/components/FAQ";
import WhyChoose from "@/components/WhyChoose";
import Contact from "@/components/Contact";
import Footer from "@/components/Footer";
import ScrollAnimationProvider from "@/components/ScrollAnimationProvider";

export default function Home() {
  return (
    <ScrollAnimationProvider>
      <Navbar />
      <Hero />
      <Marquee />
      <Services />
      <AiIntegration />
      <About />
      <Consulting />
      <Testimonials />
      <ConsultingProcess />
      <ToolsTech />
      <Verticals />
      <Pricing />
      <FAQ />
      <WhyChoose />
      <Contact />
      <Footer />
    </ScrollAnimationProvider>
  );
}
